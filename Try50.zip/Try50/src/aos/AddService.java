package aos;

public class AddService implements AddInterface{

	
	
	public int add() {
		
		return 5;
	}

}
