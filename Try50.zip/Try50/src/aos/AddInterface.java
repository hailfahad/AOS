package aos;

public interface AddInterface {
	public int add();
}
